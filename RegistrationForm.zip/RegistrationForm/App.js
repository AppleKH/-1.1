import React from 'react';
import AppNavigator from './Navigator'

export default function App() {
  return <AppNavigator />;
}