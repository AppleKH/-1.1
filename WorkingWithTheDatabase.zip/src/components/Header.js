import React from "react";
import "./Header.css";
const Header = () => (
  <div className="header">
    <h1>
      <i className="fa fa-shopping-bag" aria-hidden="true"></i> Мой список
      покупок
    </h1>
  </div>
);

export default Header;
