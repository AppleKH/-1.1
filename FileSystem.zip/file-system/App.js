import MainApp from "./src/views/MainApp";
import * as React from 'react';
function App() {
  return <MainApp />;
}

export default App;